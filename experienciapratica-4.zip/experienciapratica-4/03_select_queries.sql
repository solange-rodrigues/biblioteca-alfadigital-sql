-- Ver todos os materiais cadastrados
SELECT * FROM Material;

-- Ver todas as categorias cadastradas
SELECT * FROM Categoria;

-- Ver todas as classifica��es existentes
SELECT * FROM Classifica;

-- Ver os materiais classificados como 'Alta' relev�ncia
SELECT M.titulo, C.relevancia
FROM Material M
JOIN Classifica C ON M.cod_material = C.cod_material
WHERE C.relevancia = 'Alta';

-- Ver os materiais publicados ap�s 2021
SELECT titulo, ano_pub
FROM Material
WHERE ano_pub > 2021;

-- Ver os 2 materiais mais recentes
SELECT TOP 2 titulo, ano_pub
FROM Material
ORDER BY ano_pub DESC;

-- Ver os materiais e suas categorias (somente se houver rela��o v�lida)
SELECT M.titulo, Cat.descricao
FROM Material M
JOIN Classifica C ON M.cod_material = C.cod_material
JOIN Categoria Cat ON C.cod_categoria = Cat.cod_categoria;

-- Contar quantos materiais existem por tipo
SELECT tipo_material, COUNT(*) AS total
FROM Material
GROUP BY tipo_material;
