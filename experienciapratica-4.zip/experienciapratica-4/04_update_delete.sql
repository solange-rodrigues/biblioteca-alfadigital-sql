-- Atualizar o nome de um material
UPDATE Material
SET titulo = 'Algoritmos e Pensamento Computacional'
WHERE cod_material = 101;

-- Atualizar a relev�ncia de um material
UPDATE Classifica
SET relevancia = 'M�dia'
WHERE cod_material = 103;

-- Atualizar a descri��o de uma categoria
UPDATE Categoria
SET descricao = 'Tecnologia da Informa��o'
WHERE cod_categoria = 1;

-- Excluir a classifica��o que usa a categoria 3
DELETE FROM Classifica
WHERE cod_categoria = 3;

-- Agora sim: excluir a categoria 3
DELETE FROM Categoria
WHERE cod_categoria = 3;

-- Excluir a classifica��o que usa o material 103 (Midia_Digital)
DELETE FROM Classifica
WHERE cod_material = 103;

-- Agora sim: excluir o material do tipo 'Midia_Digital'
DELETE FROM Material
WHERE tipo_material = 'Midia_Digital';
SELECT * FROM Material;
SELECT * FROM Categoria;
SELECT * FROM Classifica;
