-- Inserindo categorias
INSERT INTO Categoria (cod_categoria, descricao) VALUES
(1, 'Tecnologia'),
(2, 'Educa��o'),
(3, 'Sa�de');

-- Inserindo materiais
INSERT INTO Material (cod_material, titulo, ano_pub, tipo_material) VALUES
(101, 'Algoritmos e L�gica', 2022, 'Livro'),
(102, 'Revista Ci�ncia Hoje', 2023, 'Periodico'),
(103, 'Curso de SQL Interativo', 2021, 'Midia_Digital');

-- Classificando materiais
INSERT INTO Classifica (cod_categoria, cod_material, relevancia) VALUES
(1, 101, 'Alta'),
(2, 102, 'M�dia'),
(1, 103, 'Alta');
